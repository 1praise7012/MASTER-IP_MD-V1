module.exports = require('./masterIp')
