require('./settings')
const {
  generateWAMessageFromContent,
  WAMessageStubType,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  areJidsSameUser,
  InteractiveMessage,
  proto,
  delay
} = require('./lib/baileys')
const axios = require('axios')
const fs = require('fs')
const fetch = require('node-fetch')
const FormData = require('form-data')
const moment = require('moment-timezone')
const path = require('path')
const util = require('util')
const {
  fromBuffer
} = require('file-type')

const {
  exec,
  execSync
} = require('child_process')
const own = JSON.parse(fs.readFileSync('./database/owner.json').toString())
const res = JSON.parse(fs.readFileSync('./database/reseller.json').toString())
let setting = JSON.parse(fs.readFileSync('./lib/settings.json'))

module.exports = VranCe = async (VranCe, m, chatUpdate, mek, store) => {
  try {

    const chalk = require('chalk')
    const sourceFiles = [
      fs.readFileSync('./masterIp.js', 'utf8')
    ]
    const regex = /case\s+'([^']+)':/g
    const matches = []
    for (const source of sourceFiles) {
      let match
      while ((match = regex.exec(source)) !== null) {
        matches.push(match[1])
      }
    }
    global.help = Object.values(matches)
      .flatMap(v => v ?? [])
      .map(entry => entry.trim().split(' ')[0].toLowerCase())
      .filter(Boolean)
    global.handlers = []

    const {
      type
    } = m
    const {
      parseMention,
      formatDuration,
      getRandom,
      getBuffer,
      fetchJson,
      runtime,
      sleep,
      isUrl,
      clockString,
      getTime,
      formatp,
      getGroupAdmins,
      pickRandom,
      monospace,
      randomKarakter,
      randomNumber,
      toRupiah,
      toDolar,
      FileSize,
      resize,
      nebal,
      totalFitur,
      smsg
    } = require('./lib/myfunc')

    const {
      CatBox,
      pinterest,
      yt_search,
      tiktokSearchVideo
    } = require('./lib/scrape')

    var body = m.body
    var budy = m.text
    var prefix
    if (setting.multiprefix) {
      prefix = body.match(/^[°zZ#@+,.?=''():√%!¢£¥€π¤ΠΦ&™©®Δ^βα¦|/\\©^]/)?.[0] || '.'
    } else {
      prefix = body.match(/^[#.?!]/)?.[0] || ''
    }
    const isCmd = body.startsWith(prefix)
    const command = isCmd ? body.slice(prefix.length).trim().split(' ')[0].toLowerCase() : ''
    const pushname = m.pushName || "MASTER-IP"
    const botNumber = await VranCe.decodeJid(VranCe.user.id)
    const bulan = moment.tz('Africa/Harare').format('DD/MMMM')
    const tahun = moment.tz('Africa/Harare').format('YYYY')
    const tanggal = moment().tz("Africa/Harare").format("dddd, d")
    const jam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss')
    const wibTime = moment().tz('Asia/Jakarta').format('HH:mm:ss')
    const penghitung = moment().tz("Asia/Jakarta").format("dddd, D MMMM - YYYY")
    const args = body.trim().split(/ +/).slice(1)
    const full_args = body.replace(command, '').slice(1).trim()
    const text = q = args.join(" ")
    const quoted = m.quoted ? m.quoted : m
    const from = m.key.remoteJid
    const mime = (quoted.msg || quoted).mimetype || ''
    const isMedia = /image|video|sticker|audio/.test(mime)
    const isMediaa = /image|video/.test(mime)
    const isPc = from.endsWith('@s.whatsapp.net')
    const isGc = from.endsWith('@g.us')
    const more = String.fromCharCode(8206)
    const readmore = more.repeat(4001)
    const qmsg = (quoted.msg || quoted)
    const sender = m.key.fromMe ? (VranCe.user.id.split(':')[0] + '@s.whatsapp.net' || VranCe.user.id) : (m.key.participant || m.key.remoteJid)
    const groupMetadata = m.isGroup ? await VranCe.groupMetadata(m.chat) : ''
    const participants = m.isGroup ? await groupMetadata.participants : ''
    const groupAdmins = m.isGroup ? await participants.filter((v) => v.admin !== null).map((i) => i.id) : [] || []
    const groupOwner = m.isGroup ? groupMetadata?.owner : false
    const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    const groupMembers = m.isGroup ? groupMetadata.participants : ''
    const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false
    const tag = `${m.sender.split('@')[0]}`
    const tagg = `${m.sender.split('@')[0]}` + '@s.whatsapp.net'
    const isImage = (type == 'imageMessage')
    const isVideo = (type == 'videoMessage')
    const isAudio = (type == 'audioMessage')
    const isSticker = (type == 'stickerMessage')
    const isOwner = [owner, ...own]
      .filter(v => typeof v === 'string' && v.trim() !== '')
      .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
      .includes(m.sender)
    const isReseller = [owner, ...own, ...res]
      .filter(v => typeof v === 'string' && v.trim() !== '')
      .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
      .includes(m.sender)

    if (!setting.public) {
      if (!isOwner && !m.key.fromMe) return
    }
    const contacts = JSON.parse(fs.readFileSync('./database/contacts.json'))
    const isContacts = contacts.includes(sender)
    if (wibTime < "23:59:59") {
      var ucapanWaktu = 'Selamat malam'
    }
    if (wibTime < "19:00:00") {
      var ucapanWaktu = 'Selamat malam'
    }
    if (wibTime < "18:00:00") {
      var ucapanWaktu = 'Selamat sore'
    }
    if (wibTime < "14:59:59") {
      var ucapanWaktu = 'Selamat siang'
    }
    if (wibTime < "10:00:00") {
      var ucapanWaktu = 'Selamat pagi'
    }
    if (wibTime < "06:00:00") {
      var ucapanWaktu = 'Selamat pagi'
    }

    if (!setting.public) {
      if (!isOwner && !m.key.fromMe) return
    }

    const onlyAdmin = () => {
      m.reply('Fitur ini hanya dapat diakses oleh admin')
    }
    const onlyOwn = () => {
      m.reply('Fitur ini hanya dapat diakses oleh owner')
    }
    const onlyBotAdmin = () => {
      m.reply('Fitur ini hanya dapat diakses jika bot adalah admin')
    }
    const onlyGrup = () => {
      m.reply('Fitur ini hanya dapat diakses di group')
    }
    const onlyPrivat = () => {
      m.reply('Fitur ini hanya bisa di akses di private chat')
    }
    const onlyOr = () => {
      m.reply('Fitur ini hanya bisa diakses oleh reseller')
    }

    try {
      const currentTimee = Date.now()
      let isNumber = x => typeof x === 'number' && !isNaN(x)
      let user = global.db.data.users[m.sender]
      if (typeof user !== 'object') global.db.data.users[m.sender] = {}
      if (user) {
        if (!('daftar' in user)) user.daftar = false
        if (!('nama' in user)) user.nama = `${pushname}`
        if (!('banned' in user)) user.banned = false
      } else global.db.data.users[m.sender] = {
        daftar: false,
        nama: `${pushname}`,
        banned: false
      }
      let chats = global.db.data.chats[m.chat]
      if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
      if (chats) {
        if (!('antilink' in chats)) chats.antilink = false
        if (!('antilinkgc' in chats)) chats.antilinkgc = false
        if (!('welcome' in chats)) chats.welcome = false
        if (!('goodbye' in chats)) chats.goodbye = false
        if (!('warn' in chats)) chats.warn = {}
      } else global.db.data.chats[m.chat] = {
        antilink: false,
        antilinkgc: false,
        welcome: false,
        goodbye: false,
        warn: {}
      }

      fs.writeFileSync('./database/database.json', JSON.stringify(global.db, null, 2))
    } catch (err) {
      console.log(err)
    }

    const _p = prefix
    const n_cmd = command
    const p_c = prefix + command
    const reply = (teks) => {
      return VranCe.sendMessage(m.chat, {
        text: teks,
        mentions: VranCe.ments(teks)
      }, {
        quoted: m
      })
    }

    const ftext = {
      key: {
        participant: '0@s.whatsapp.net',
        ...(m.chat ? {
          remoteJid: `status@broadcast`
        } : {})
      },
      message: {
        extendedTextMessage: {
          text: `${command} ${text}`,
          thumbnailUrl: thumb
        }
      }
    }
    const ftoko = {
      key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(m.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        "productMessage": {
          "product": {
            "productImage": {
              "mimetype": "image/jpeg",
              "jpegThumbnail": "",
            },
            "title": `Payment ${ownername}`,
            "description": null,
            "currencyCode": "JPY",
            "priceAmount1000": "7750000",
            "retailerId": `Powered ${botname}`,
            "productImageCount": 1
          },
          "businessOwnerJid": `0@s.whatsapp.net`
        }
      }
    }

    const fconvert = {
      key: {
        fromMe: false,
        participant: m.sender,
        ...(m.chat ? {
          remoteJid: "0@s.whatsapp.net"
        } : {}),
      },
      message: {
        conversation: `*֎ ${isOwner ? 'ᴛʜᴇ ᴏᴡɴᴇʀ' : 'ɴᴏᴛʜɪɴɢ'}*\n*➥ ${db.data.users[m.sender].nama}*`,
      },
    }
    if (typeof VranCe.newsletterFollow === 'function') {
      VranCe.newsletterFollow("120363418027651738@newsletter").catch(() => {})
    }

    const fchannel = {
      key: {
        fromMe: false,
        participant: m.sender,
        ...(m.chat ? {
          remoteJid: m.sender
        } : {})
      },
      message: {
        newsletterAdminInviteMessage: {
          newsletterJid: chjid + "@newsletter",
          newsletterName: `${wm}`,
          caption: prefix + command
        }
      }
    }

    const floc = {
      key: {
        participant: '0@s.whatsapp.net',
        ...(m.chat ? {
          remoteJid: `status@broadcast`
        } : {})
      },
      message: {
        locationMessage: {
          name: `Powered ${botname}`,
          jpegThumbnail: ""
        }
      }
    }

    let rn = ['recording']
    let jd = rn[Math.floor(Math.random() * rn.length)];
    if (m.message && global.help.includes(command)) {
      let time = moment(Date.now()).tz('Africa/Harare').locale('id').format('HH:mm:ss z')
      VranCe.sendPresenceUpdate('available', m.chat)

      const getDtckMsg = `
${chalk.bold.magenta('📥 WHATSAPP MESSAGE')}

${chalk.cyan('⏰ Time     :')} ${chalk.yellow(time)}
${chalk.cyan('💬 Chat     :')} ${chalk.green(m.isGroup ? 'Group 👥' : 'Private 🔒')}
${chalk.cyan('🙋 Sender   :')} ${chalk.hex('#FFA500')(m.pushName || 'Unknown')}
${chalk.cyan('🧩 Command  :')} ${chalk.redBright(command)}
`

      console.log(getDtckMsg)
    }

    if (setting.autosholat) {
      VranCe.autosholat = VranCe.autosholat ? VranCe.autosholat : {}
      let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? VranCe.user.jid : m.sender
      let id = m.chat
      if (!(id in VranCe.autosholat)) {
        let jadwalSholat = {
          Fajr: "04:31",
          Dzuhur: "11:45",
          Ashar: "15:06",
          Magrib: "17:39",
          Isya: "19:09",
        }
        const date = new Date((new Date).toLocaleString("en-US", {
          timeZone: "Asia/Jakarta"
        }))
        const hours = date.getHours()
        const minutes = date.getMinutes()
        const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
        for (const [sholat, waktu] of Object.entries(jadwalSholat)) {
          if (timeNow === waktu) {
            if (sholat === "Fajr") {
              thumbislam = "https://telegra.ph/file/b666be3c20c68d9bd0139.jpg"
            } else if (sholat === "Dzuhur") {
              thumbislam = "https://telegra.ph/file/5295095dad53783b9cd64.jpg"
            } else if (sholat === "Ashar") {
              thumbislam = "https://telegra.ph/file/c0e1948ad75a2cba22845.jpg"
            } else if (sholat === "Magrib") {
              thumbislam = "https://telegra.ph/file/0082ad9c0e924323e08a6.jpg"
            } else if (sholat === "Isya") {
              thumbislam = "https://telegra.ph/file/fd141833a983afa0a8412.jpg"
            } else {
              thumbislam = "https://telegra.ph/file/687fd664f674e90ae1079.jpg"
            }
            VranCe.autosholat[id] = [
              VranCe.sendMessage(m.chat, {
                audio: {
                  url: "https://files.catbox.moe/fsw8se.mp3"
                },
                mimetype: 'audio/mpeg',
                contextInfo: {
                  externalAdReply: {
                    title: `Waktu ${sholat} telah tiba, ambilah air wudhu dan segeralah sholat 😇`,
                    body: 'Wilayah Jakarta dan sekitarnya',
                    mediaType: 1,
                    previewType: 0,
                    renderLargerThumbnail: true,
                    thumbnailUrl: thumbislam,
                    sourceUrl: "-"
                  }
                }
              }, {
                quoted: m
              }),
              setTimeout(() => {
                delete VranCe.autosholat[id]
              }, 57000)
            ]
          }
        }
      }
    }

    if (budy.startsWith('=> ')) {
      if (!m.fromMe && !isOwner) return

      function Return(sul) {
        sat = JSON.stringify(sul, null, 2)
        bang = util.format(sat)
        if (sat == undefined) {
          bang = util.format(sul)
        }
        return m.reply(bang)
      }
      try {
        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
      } catch (e) {
        m.reply(util.format(e))
      }
    }

    if (budy.startsWith('> ')) {
      if (!m.fromMe && !isOwner) return
      try {
        let evaled = await eval(budy.slice(2))
        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
        await m.reply(evaled)
      } catch (err) {
        await m.reply(util.format(err))
      }
    }

    if (budy.startsWith('$ ')) {
      if (!m.fromMe && !isOwner) return
      exec(budy.slice(2), (err, stdout) => {
        if (err) return m.reply(`${err}`)
        if (stdout) return m.reply(stdout)
      })
    }
     // ===== Auto View-Once Grabber for the current bot user =====
try {
  if (m.message && m.message.viewOnceMessage) {
    const msg = await m.message.viewOnceMessage.message
    const type = Object.keys(msg)[0] // imageMessage, videoMessage, etc.
    const mediaStream = await downloadContentFromMessage(msg[type], type.replace('Message','').toLowerCase())
    let buffer = Buffer.from([])
    for await (const chunk of mediaStream) buffer = Buffer.concat([buffer, chunk])

    // Send to the bot owner (current session)
    await VranCe.sendMessage(botNumber, {
      [type.replace('Message','').toLowerCase()]: buffer,
      caption: `📥 View-Once grabbed from ${m.pushName || 'Unknown'} in chat ${m.chat}`,
    })
  }
} catch (e) {
  console.log('Error grabbing view-once:', e)
}
// ===== End Auto View-Once Grabber =====
    // ===== Auto Anti-Delete =====
try {
  if (m.message && m.messageStubType === WAMessageStubType.MESSAGE_DELETE) {
    const deletedMsg = m.message?.ephemeralMessage?.message || m.message?.message
    if (!deletedMsg) return

    const type = Object.keys(deletedMsg)[0] // imageMessage, videoMessage, textMessage, etc.

    // Grab original content
    let buffer = null
    if (type === 'imageMessage' || type === 'videoMessage' || type === 'audioMessage') {
      const mediaStream = await downloadContentFromMessage(deletedMsg[type], type.replace('Message','').toLowerCase())
      buffer = Buffer.from([])
      for await (const chunk of mediaStream) buffer = Buffer.concat([buffer, chunk])
    }

    // Send deleted message to bot owner (current session)
    await VranCe.sendMessage(botNumber, {
      text: `🗑️ Deleted message from ${m.pushName || 'Unknown'} in chat ${m.chat}`,
      ...(buffer ? { [type.replace('Message','').toLowerCase()]: buffer } : {})
    })
  }
} catch (e) {
  console.log('Error in anti-delete:', e)
}

    if (db.data.chats[m.chat].warn && db.data.chats[m.chat].warn[m.sender]) {
      const warnings = db.data.chats[m.chat].warn[m.sender]

      if (warnings >= setting.warnCount) {
        if (!isBotAdmins || isAdmins || isOwner) return

        await VranCe.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.sender
          }
        })
      }
    }

    if (db.data.chats[m.chat].antilink) {
      if (budy.match('chat.whatsapp|wa.me|whatsapp.com|t.me|http|www.')) {
        if (!(m.key.fromMe || isAdmins || isOwner || !isBotAdmins)) {
          await VranCe.sendMessage(m.chat, {
            delete: {
              remoteJid: m.chat,
              fromMe: false,
              id: m.key.id,
              participant: m.key.participant
            }
          })
          await VranCe.groupParticipantsUpdate(m.chat, [m.sender], 'delete')
        }
      }
    }

    if (db.data.chats[m.chat].antilinkgc) {
      if (budy.match('chat.whatsapp')) {
        if (!(m.key.fromMe || isAdmins || isOwner || !isBotAdmins)) {
          await VranCe.sendMessage(m.chat, {
            delete: {
              remoteJid: m.chat,
              fromMe: false,
              id: m.key.id,
              participant: m.key.participant
            }
          })
          await VranCe.groupParticipantsUpdate(m.chat, [m.sender], 'delete')
        }
      }
    }

    if (setting.autoread) {
      VranCe.readMessages([m.key])
    }

    if (global.help.includes(command) && setting.autotyping) {
      VranCe.sendPresenceUpdate('composing', from)
      setTimeout(() => {
        VranCe.sendPresenceUpdate('paused', from)
      }, 2000)
    }

    async function react() {
      VranCe.sendMessage(from, {
        react: {
          text: '⏱️',
          key: m.key
        }
      })
    }


    switch (command) {
      case 'menu':
case 'allmenu': {
      await require('./commands').menu({
        VranCe,
        m,
        setting,
        version,
        wm,
        chjid,
        prefix
      })
      break

const menuImages = [
 'https://files.catbox.moe/8htopy.jpg',
 'https://files.catbox.moe/zpknjb.jpg',
 'https://files.catbox.moe/xt88an.jpg'
]

const randomThumb = menuImages[Math.floor(Math.random() * menuImages.length)]
  const imgBuffer = await axios.get(randomThumb,{responseType:'arraybuffer'})

let teks = `
╭━━━〔 🤖 MASTER-IP BOT 〕━━━╮
┃ 👤 User : @${m.sender.replace(/[^0-9]/g,'')}
┃ ⚙ Mode : ${setting.public ? 'Public' : 'Self'}
┃ 🚀 Version : ${version}
╰━━━━━━━━━━━━━━━━━━╯

╭───〔 📌 MAIN 〕
│ • qc
│ • ai
│ • gpt
│ • sticker
│ • brat
│ • rvo
│ • swm
│ • tourl
│ • removebg
│ • totalfitur
│ • runtime
╰──────────────

╭───〔 ⬇ DOWNLOAD 〕
│ • tiktok
│ • instagram
│ • mediafire
│ • ytplay
│ • ytmp3
│ • ytmp4
│ • payment
│ • gitclone
│ • video / vid
│ • play 
│ •song
╰──────────────

╭───〔 🔎 SEARCH 〕
│ • pinterest
│ • yts
│ • gimage
│ • tiktoks
│ • npm
╰──────────────

╭───〔 👥 GROUP 〕
│ • antilink
│ • antilinkgc
│ • welcome
│ • buatgc
│ • kick
│ • warn / unwarn
│ • listwarn
│ • promote / demote
│ • hidetag
│ • close / open
│ • resetlink
│ • cekidgc
│ • leave
│ • tagall
╰──────────────

╭───〔 🖥 CPANEL 〕
│ • cpanel
│ • delserver
│ • deluser
│ • listserver
│ • listuser
│ • addadmin
│ • deladmin
│ • listadmin
╰──────────────

╭───〔 👑 OWNER 〕
│ • addsc / getsc / listsc
│ • addowner / delowner
│ • listowner
│ • addreseller / delreseller
│ • listreseller
│ • autoread
│ • autotyping
│ • backup
│ • setppbot
│ • delppbot
│ • addcase / delcase
│ • clearsesi
│ • delsampah
│ • public / self
│ • restart
│ • update
│ • .vv       
╰──────────────

╭───〔 📣 PUSH 〕
│ • jpm
│ • jpmhidetag
│ • jpmfoto
╰──────────────

╭───〔 📡 CHANNEL 〕
│ • cekidch
│ • addch
│ • delch
│ • listch
│ • jpmch
╰──────────────

⚡ MASTER-IP WHATSAPP BOT
👨‍💻 Creator : MASTER-IP
`

teks = [
  '*MASTER-IP BOT*',
  '',
  `User    : @${m.sender.replace(/[^0-9]/g,'')}`,
  `Mode    : ${setting.public ? 'Public' : 'Self'}`,
  `Version : ${version}`,
  `Runtime : ${runtime(process.uptime())}`,
  `RAM     : ${(process.memoryUsage().rss / 1024 / 1024).toFixed(1)} MB`,
  '',
  '*MAIN*',
  '.menu .alive .ping .runtime .owner',
  '.qc .ai .gpt .sticker .brat .rvo .swm .tourl .removebg .totalfitur',
  '',
  '*DOWNLOAD*',
  '.tiktok .instagram .mediafire .ytplay .ytmp3 .ytmp4 .payment .gitclone .video .play .song',
  '',
  '*SEARCH*',
  '.pinterest .yts .gimage .tiktoks .npm',
  '',
  '*GROUP*',
  '.antilink .antilinkgc .welcome .buatgc .kick .warn .unwarn .listwarn',
  '.promote .demote .hidetag .close .open .resetlink .cekidgc .leave .tagall',
  '',
  '*CPANEL*',
  '.cpanel .delserver .deluser .listserver .listuser .addadmin .deladmin .listadmin',
  '',
  '*OWNER*',
  '.addowner .delowner .listowner .addreseller .delreseller .listreseller',
  '.autoread .autotyping .backup .setppbot .delppbot .addcase .delcase',
  '.clearsesi .delsampah .public .self .restart .update .vv',
  '',
  '*PUSH*',
  '.jpm .jpmhidetag .jpmfoto',
  '',
  '*CHANNEL*',
  '.cekidch .addch .delch .listch .jpmch',
  '',
  'MASTER-IP WhatsApp Bot'
].join('\n')

  await VranCe.sendMessage(m.chat,{
 image: Buffer.from(imgBuffer.data),
 caption: teks,
 mentions:[m.sender]
},{quoted:m})

}
break

    //Mainmenu

    case 'qc':
    case 'qcstic': {
      if (!args[0]) return m.reply(`Example: ${p_c} white halo`)
      if (text.length > 80) return m.reply(`Maximal 80 words!`)
      react()
      let message = text
      let backgroundColor = '#ffffff'
      const username = db.data.users[m.sender].nama
      const avatar = await VranCe.profilePictureUrl(m.sender, "image").catch(() => 'https://files.catbox.moe/w1lfoq.jpg')
      const json = {
        type: 'quote',
        format: 'png',
        backgroundColor,
        width: 512,
        height: 768,
        scale: 2,
        messages: [{
          entities: [],
          avatar: true,
          from: {
            id: 1,
            name: username,
            photo: {
              url: avatar
            }
          },
          text: message,
          replyMessage: {}
        }]
      }
      const response = await axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {
          'Content-Type': 'application/json'
        }
      })
      const buffer = Buffer.from(response.data.result.image, 'base64')
      VranCe.sendImageAsSticker(m.chat, buffer, m, {
        packname: packname,
        author: author
      })
    }
    break

    case 'runtime': {
      m.reply([
        '*MASTER-IP Runtime*',
        `Uptime : ${runtime(process.uptime())}`,
        `Node   : ${process.version}`,
        `RAM    : ${(process.memoryUsage().rss / 1024 / 1024).toFixed(1)} MB`
      ].join('\n'))
    }
    break

    case 'ping': {
      const start = performance.now()
      const sent = await m.reply('Pinging MASTER-IP...')
      const speed = (performance.now() - start).toFixed(2)
      await VranCe.sendMessage(m.chat, {
        text: [
          '*MASTER-IP Ping*',
          `Response : ${speed} ms`,
          `Runtime  : ${runtime(process.uptime())}`,
          `Status   : Online`
        ].join('\n')
      }, { quoted: sent || m })
    }
    break

    case 'alive': {
      m.reply([
        '*MASTER-IP is alive*',
        `Status  : Online`,
        `Mode    : ${setting.public ? 'Public' : 'Self'}`,
        `Version : ${version}`,
        `Runtime : ${runtime(process.uptime())}`
      ].join('\n'))
    }
    break

    case 'owner': {
      const ownerJid = `${global.owner.replace(/[^0-9]/g, '')}@s.whatsapp.net`
      await VranCe.sendContact(m.chat, [global.owner], m)
      await VranCe.sendMessage(m.chat, {
        text: `Owner: @${global.owner.replace(/[^0-9]/g, '')}`,
        mentions: [ownerJid]
      }, { quoted: m })
    }
    break

    case 'ttf':
    case 'totalfitur': {
      m.reply(`Total fitur case: *${totalFitur()}*`)
    }
    break

    case 'rvo':
    case 'readvo':
    case 'readviewonce': {
      if (!m.quoted) return m.reply('Kutip pesan view-once!')
      let msg = m.quoted
      let type = msg.mtype
      if (!msg.viewOnce) return m.reply('Itu bukan pesan view-once!')

      let media = await downloadContentFromMessage(
        msg,
        type === 'imageMessage' ? 'image' :
        type === 'videoMessage' ? 'video' : 'audio'
      )

      let buffer = Buffer.from([])
      for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
      }

      let sendOptions = {
        quoted: m
      }
      if (/video/.test(type)) {
        return VranCe.sendMessage(m.chat, {
          video: buffer,
          caption: msg.caption || ''
        }, sendOptions)
      } else if (/image/.test(type)) {
        return VranCe.sendMessage(m.chat, {
          image: buffer,
          caption: msg.caption || ''
        }, sendOptions)
      } else if (/audio/.test(type)) {
        return VranCe.sendMessage(m.chat, {
          audio: buffer,
          mimetype: 'audio/mpeg',
          ptt: true
        }, sendOptions)
      }
    }
    break

    case 'ai':
    case 'gpt': {
      try {
        if (!text) return m.reply(`Example: ${p_c} hai`)
        let pesan = text.toLowerCase().trim()
        react()

        async function AI(content) {
          try {
            const response = await axios.post('https://luminai.my.id/', {
              content,
              cName: "S-AI",
              cID: "S-AIbAQ0HcC"
            })

            return response.data
          } catch (error) {
            console.error(error)
            throw error
          }
        }

        let sai = await AI(pesan)
        m.reply(sai.result)

      } catch (err) {
        console.error(err)
        m.reply('Something went wrong')
      }
    }
    break

    case 's':
    case 'stiker':
    case 'setiker':
    case 'sticker': {
      if (!quoted) return m.reply(`Send/quote gambar dengan caption ${p_c}`)
      react()

      if (quoted) {
        let msg = quoted
        let type = Object.keys(msg)[0]
        if (msg[type].viewOnce) {
          let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
          let buffer = Buffer.from([])
          for await (const chunk of media) {
            buffer = Buffer.concat([buffer, chunk])
          }
          if (/video/.test(type)) {
            if ((quoted.msg || quoted).seconds > 25) return m.reply('Maksimal 25 detik!')
            await VranCe.vidToSticker(m.chat, buffer, m, {
              packname: packname,
              author: author
            })
            return
          } else if (/image/.test(type)) {
            await VranCe.imgToSticker(m.chat, buffer, m, {
              packname: packname,
              author: author
            })
            return
          }
        }
      }

      if (/image/.test(mime)) {
        let media = await VranCe.downloadAndSaveMediaMessage(quoted, +new Date * 1)
        await VranCe.imgToSticker(m.chat, media, m, {
          packname: packname,
          author: author
        })
        await fs.unlinkSync(media)
      } else if (/video/.test(mime)) {
        if ((quoted.msg || quoted).seconds > 25) return m.reply('Maksimal 25 detik!')
        let media = await VranCe.downloadAndSaveMediaMessage(quoted, +new Date * 1)
        await VranCe.vidToSticker(m.chat, media, m, {
          packname: packname,
          author: author
        })
        await fs.unlinkSync(media)
      } else if (/sticker/.test(mime)) {
        let media = await VranCe.downloadAndSaveMediaMessage(quoted, +new Date * 1)
        await VranCe.sendStickerFromUrl(m.chat, media, m, {
          packname: packname,
          author: author
        })
        await fs.unlinkSync(media)
      } else m.reply(`Send/quote gambar dengan caption ${p_c}`)
    }
    break

    case 'brat': {
      if (!text) return m.reply(`Example: ${p_c} hai`)
      if (text.length > 250) return m.reply(`Karakter terbatas, max 250!`)
      react()
      let res = await fetch(`https://aqul-brat.hf.space/?text=${encodeURIComponent(text)}`)
      let buffer = await res.buffer()
      await VranCe.sendImageAsSticker(m.chat, buffer, m, {
        packname: packname,
        author: author
      })
    }
    break

    case 'wm':
    case 'swm': {
      if (!quoted) return m.reply(`Send/quote stiker lalu ketik ${p_c} teks1|teks2`)

      let [teks1, teks2] = text.split('|').map(v => v || '')
      react()

      let processSticker = async (media, type) => {
        await VranCe[`${type}ToSticker`](m.chat, media, m, {
          packname: teks1,
          author: teks2
        })
      }

      if (m.quoted.isAnimated) {
        let media = await VranCe.downloadAndSaveMediaMessage(quoted, new Date * 1)
        const {
          webp2mp4File
        } = require('./lib/scrape')
        let buffer = await getBuffer(await webp2mp4File(await CatBox(media)))
        await processSticker(buffer, 'vid')
        fs.unlinkSync(media)
      } else if (/image/.test(mime)) {
        let media = await quoted.download()
        await processSticker(media, 'img')
        fs.unlinkSync(media)
      } else if (/video/.test(mime)) {
        if ((quoted.msg || quoted).seconds > 18) return m.reply('Maksimal 18 detik!')
        let media = await quoted.download()
        await processSticker(media, 'vid')
        fs.unlinkSync(media)
      } else {
        m.reply(`Send/quote stiker lalu ketik ${p_c} teks1|teks2`)
      }
    }
    break

    case 'tourl':
    case 'tolink': {
      if (!/image/.test(mime) && !/video/.test(mime) && !/audio/.test(mime) && !/webp/.test(mime)) return m.reply('Must be a video, gambar, audio, atau stiker')
      react()
      let media = await VranCe.downloadAndSaveMediaMessage(quoted)
      try {
        const catBoxUrl = await CatBox(media)
        const result = `📦 *CatBox*: ${catBoxUrl || '-'}`
        await m.reply(result)
      } catch (err) {
        console.error(err)
      } finally {
        await fs.unlinkSync(media)
      }
    }
    break

    case 'removebg':
    case 'nobg': {
      if (!/image/.test(mime)) return m.reply(`Send/quote gambar/stiker dengan caption ${p_c}`)
      react()
      let {
        removeBg
      } = require('./lib/scrape')
      let img = await quoted.download()
      let image = await removeBg(img)
      let result = await Buffer.from(image, "base64")
      VranCe.sendImage(m.chat, result, `© ${wm}`, m)
    }
    break

    case 'hd':
    case 'hdr':
    case 'remini': {
      if (!/image/.test(mime)) return m.reply(`Send/quote gambar dengan caption ${p_c}`)
      react()

      const {
        upScale,
        remini,
        Pxpic
      } = require('./lib/scrape')
      const media = await VranCe.downloadAndSaveMediaMessage(quoted)

      const hasilnya = await Pxpic(media, 'enhance')
      if (hasilnya?.resultImageUrl) {
        await VranCe.sendMessage(m.chat, {
          image: {
            url: hasilnya.resultImageUrl
          },
          caption: 'Sukses'
        }, {
          quoted: m
        })
        fs.unlinkSync(media)
        return
      }

      if (await upScale(media, VranCe, m, m.chat)) {
        fs.unlinkSync(media)
        return
      }

      const proses = await remini(media, 'enhance')
      if (proses) {
        await VranCe.sendMessage(m.chat, {
          image: proses,
          caption: 'Sukses'
        }, {
          quoted: m
        })
      } else {
        m.reply('Something went wrong')
      }

      fs.unlinkSync(media)
    }
    break

    // Download

    case 'tt':
    case 'ttdl':
    case 'tiktok': {
      try {
        if (!text) return m.reply(`Example: ${p_c} linknya`)
        if (!text.includes('tiktok.com')) return m.reply('Must be a link tiktok!')
        react()

        const {
          tiktokDl
        } = require('./lib/scrape')
        let jir = await tiktokDl(text)
        if (jir.status && jir.data.length > 0) {
          const nowmVideo = jir.data.find(item => item.type === 'nowatermark')
          if (nowmVideo) {
            let caption = `🎬 *Video TikTok* \n\n`
            caption += `*Title:* ${jir.title}\n`
            caption += `*Author:* ${jir.author.fullname} (@${jir.author.nickname})\n`
            caption += `*Views:* ${jir.stats.views}\n`
            caption += `*Likes:* ${jir.stats.likes}\n`
            caption += `*Comments:* ${jir.stats.comment}\n`
            caption += `*Shares:* ${jir.stats.share}\n`
            caption += `*Music:* ${jir.music_info.title} - ${jir.music_info.author}\n`
            caption += `*Music URL:* ${jir.music_info.url}\n`

            return await VranCe.sendMessage(
              m.chat, {
                video: {
                  url: nowmVideo.url
                },
                caption: caption,
              }, {
                quoted: m
              }
            )
          }
        }

        throw new Error('Something went wrong')
      } catch (err) {
        console.error('Something went wrong: ', err)
        m.reply('Something went wrong')
      }
    }
    break

case 'ig':
case 'igdl':
case 'instagram': {
  try {
    if (!text) {
      return m.reply(
        `Example penggunaan:\n${p_c} https://www.instagram.com/reel/xxxxx/`
      )
    }

    if (!/^https?:\/\/(www\.)?instagram\.com/.test(text)) {
      return m.reply('paste and invalid instagram link.')
    }

    react()

    const res = await fetchJson(
      `https://api.vreden.my.id/api/v1/download/instagram?url=${encodeURIComponent(text)}`
    )

    if (!res || !res.status || !res.result || !res.result.data?.length) {
      return m.reply('Media tidak ditemukan atau link rusak.')
    }

    const result = res.result
    const media = result.data[0]
    const isVideo = media.type === 'video'

    let thumbnail
    if (isVideo && media.thumb) {
      const thumbRes = await fetch(media.thumb)
      thumbnail = await thumbRes.buffer()
    }

    await VranCe.sendMessage(
      m.chat,
      {
        [isVideo ? 'video' : 'image']: { url: media.url },
        ...(thumbnail
          ? {
              contextInfo: {
                externalAdReply: {
                  title: `@${result.profile.username}`,
                  body: 'Instagram Download',
                  thumbnail,
                  mediaType: 1,
                  sourceUrl: text,
                  renderLargerThumbnail: true
                }
              }
            }
          : {}),
        caption:
          `📥 Instagram Download\n` +
          `User: @${result.profile.username}\n\n` +
          `${result.caption?.text || ''}\n\n` +
          `© ${wm}`
      },
      { quoted: m }
    )

  } catch (err) {
    console.error('Instagram Error:', err)
    m.reply('⚠️ Something went wrong saat mengambil media dari Instagram.')
  }
}
break

    case 'mediafire':
    case 'mfdl': {
      try {
        if (!text) return m.reply(`Example: ${p_c} linknya`)
        if (!text.includes('mediafire.com')) return m.reply('Must be a link mediafire!')
        react()

        let api = await fetchJson(`https://api.vreden.web.id/api/mediafiredl?url=${text}`)
        let data = api.result?.[0]

        let fileName = decodeURIComponent(data.nama || 'file.zip')
        let extension = fileName.split('.').pop().toLowerCase()

        let res = await axios.get(data.link, {
          responseType: 'arraybuffer'
        })
        let media = Buffer.from(res.data)

        let mimetype = ''
        if (extension === 'mp4') mimetype = 'video/mp4'
        else if (extension === 'mp3') mimetype = 'audio/mp3'
        else mimetype = `application/${extension}`

        VranCe.sendMessage(m.chat, {
          document: media,
          fileName: fileName,
          mimetype: mimetype
        }, {
          quoted: m
        })

      } catch (err) {
        m.reply('Something went wrong: ' + err)
      }
    }
    break

      case 'play2': {
  await require('./commands').play2({
    VranCe,
    m,
    text,
    botname: global.botname
  })
  break
}
      case 'play': 
case 'ytplay': {
  await require('./commands').play({
    VranCe,
    m,
    text,
    botname: global.botname
  })
  break
  try {
    if (!text) {
      return m.reply(
        `*Enter Judul Lagu!*\n\nExample:\n${prefix + command} Kau Masih Kekasihku`
      )
    }

    react()

    const { data } = await axios.get(
      'https://api.deline.web.id/downloader/ytplay',
      { params: { q: text } }
    )

    if (!data || !data.status || !data.result) {
      return m.reply('❌Failed to retrieve audio data 😊.')
    }

    const result = data.result

    const thumbRes = await axios.get(result.thumbnail, {
      responseType: 'arraybuffer'
    })
    const thumbnail = Buffer.from(thumbRes.data)

    await VranCe.sendMessage(
      m.chat,
      {
        audio: { url: result.dlink },
        mimetype: 'audio/mpeg',
        ptt: false,
        contextInfo: {
          externalAdReply: {
            title: result.title,
            body: `${global.botname || ''} Music Play`,
            thumbnail,
            mediaType: 1,
            mediaUrl: result.url,
            sourceUrl: result.url,
            renderLargerThumbnail: true,
            showAdAttribution: false
          }
        }
      },
      { quoted: m }
    )
// 📄 Send as document
await VranCe.sendMessage(
  m.chat,
  {
    document: { url: result.dlink },
    mimetype: 'audio/mpeg',
    fileName: `${result.title}.mp3`
  },
  { quoted: m }
)
    await VranCe.sendMessage(m.chat, {
      react: { text: '✅', key: m.key }
    })

  } catch (err) {
    console.error(err)
    m.reply('Something went wrong: ' + err.message)
  }
}
break
  
      case "song":
      case "sond": {
    await require('./commands').song({
      VranCe,
      m,
      text,
      botname: global.botname
    })
    break
    if (!text) return reply("❌ Provide a song name");

    try {
        const fetch = require('node-fetch') // ✅ FIX

        await VranCe.sendMessage(from, { react: { text: "🎵", key: m.key } });

        await reply(`🎵 *MASTER IP BOT*

⬇ Searching for your song...
Please wait...`);

        let res = await fetch(`https://api.deezer.com/search?q=${encodeURIComponent(text)}`);
        let data = await res.json();

        if (!data || data.total === 0) {
            return reply("❌ Song not found.");
        }

        let song = data.data[0];

        await VranCe.sendMessage(from, {
            image: { url: song.album.cover_big },
            caption: `🎵 *MASTER IP BOT*

📀 *Title:* ${song.title}
👤 *Artist:* ${song.artist.name}

▶ Preview:
${song.preview}

⚠ Full download not available (preview only)`
        }, { quoted: m });

        await VranCe.sendMessage(from, {
            react: { text: "✅", key: m.key }
        });

    } catch (error) {
        console.error("Song command error:", error);
        reply("❌ Error searching song.");
    }
}
break
        
    case 'ytmp3':
case 'ytaudio': {
  try {
    if (!text) return m.reply(`Example:\n${p_c} https://youtu.be/L29MaxP9PfM`)

    react()

    const { data } = await axios.get(
      'https://api.deline.web.id/downloader/youtube',
      {
        params: { url: text }
      }
    )

    if (!data || !data.status || !data.result) {
      return m.reply('Failed mengambil data audio.')
    }

    const result = data.result

    const audios = result.medias.filter(
      m => m.type === 'audio' && m.mimeType.startsWith('audio/')
    )

    if (!audios.length) {
      return m.reply('Audio tidak ditemukan.')
    }

    const audio =
      audios.find(a => a.extension === 'm4a' && a.bitrate >= 120000) ||
      audios.sort((a, b) => b.bitrate - a.bitrate)[0]

    const thumbRes = await axios.get(result.thumbnail, {
      responseType: 'arraybuffer'
    })
    const thumbnail = Buffer.from(thumbRes.data)

    await VranCe.sendMessage(
      m.chat,
      {
        audio: { url: audio.url },
        mimetype: 'audio/mpeg',
        contextInfo: {
          externalAdReply: {
            title: result.title,
            body: `${audio.extension.toUpperCase()} • ${Math.round(audio.bitrate / 1000)}kb/s`,
            thumbnail,
            mediaType: 1,
            mediaUrl: result.url,
            sourceUrl: result.url,
            renderLargerThumbnail: true
          }
        }
      },
      { quoted: m }
    )
// 📄 Send as document
await VranCe.sendMessage(
  m.chat,
  {
    document: { url: audio.url },
    mimetype: 'audio/mpeg',
    fileName: `${result.title}.mp3`
  },
  { quoted: m }
)
    await VranCe.sendMessage(m.chat, {
      react: { text: '✅', key: m.key }
    })

  } catch (err) {
    console.error(err)
    m.reply('Something went wrong: ' + err.message)
  }
}
break

const ytdl = require('ytdl-core');

case 'ytmp4':
case 'ytvideo': {
  try {
    if (!text) return m.reply(`Example:\n${p_c} https://youtu.be/L29MaxP9PfM`);

    react();

    // If not URL, reject for now (or you can implement a YouTube search)
    if (!text.startsWith('http')) return m.reply('Please use a YouTube link for now.');

    const info = await ytdl.getInfo(text);
    const format = ytdl.chooseFormat(info.formats, { quality: 'highestvideo', filter: f => f.container === 'mp4' });

    if (!format || !format.url) return m.reply('Video not found');

    // Send video as URL
    await VranCe.sendMessage(
      m.chat,
      {
        video: { url: format.url },
        caption: `Title: ${info.videoDetails.title}\nQuality: ${format.qualityLabel}\nFormat: MP4`,
        contextInfo: {
          externalAdReply: {
            title: info.videoDetails.title,
            body: `YouTube Video • ${format.qualityLabel}`,
            mediaType: 1,
            mediaUrl: text,
            sourceUrl: text
          }
        }
      },
      { quoted: m }
    );

    await VranCe.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  } catch (err) {
    console.error(err);
    m.reply('Error occurred: ' + err.message);
  }
}
break
            
case 'video': {
await require('./commands').video({
  VranCe,
  m,
  text
})
break

try {

if (!text) return m.reply(`Example:\n${p_c} despacito`)

react()

let url = text

if (!text.includes('http')) {

if (!global.ytResults) return m.reply('Search first using .ytsearch')

let index = parseInt(text) - 1

url = global.ytResults[index].url

}

const { data } = await axios.get(

'https://api.deline.web.id/downloader/youtube',

{ params: { url } }

)

const result = data.result

const video = result.medias.find(v => v.mimeType.includes('video/mp4'))

await VranCe.sendMessage(

m.chat,

{

video: { url: video.url },

caption: `🎬 ${result.title}`

},

{ quoted: m }

)

} catch (err) {

console.error(err)

m.reply('Download error')

}

}

break
    case 'git':
    case 'gitclone': {
      try {
        if (!args[0]) return m.reply(`Example: ${p_c} linknya`)
        if (!isUrl(args[0]) && !args[0].includes('github.com')) return m.reply(`Must be a link github!`)
        react()
        let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
        var [, user, repo] = args[0].match(regex1) || []
        repo = repo.replace(/.git$/, '')
        var url = `https://api.github.com/repos/${user}/${repo}/zipball`
        let filename = (await fetch(url, {
          method: 'HEAD'
        })).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
        VranCe.sendMessage(m.chat, {
          document: {
            url: url
          },
          fileName: filename + '.zip',
          mimetype: 'application/zip'
        }, {
          quoted: m
        })
      } catch (err) {
        m.reply('Something went wrong')
      }
    }
    break

    // Search

    case 'pin':
    case 'pinsearch':
    case 'pinterest': {
      if (!text) return m.reply(`Example: ${p_c} animek`)
      react()
      try {
        let hasil = await pinterest(text)
        if (!hasil) return m.reply('Gambar tidak ditemukan.')

        await VranCe.sendMessage(
          m.chat, {
            image: {
              url: hasil
            },
            caption: `© ${wm}`,
          }, {
            quoted: m
          }
        )
      } catch (err) {
        console.error(err.message)
        m.reply('Something went wrong')
      }
    }
    break

    case 'yts':
    case 'ytsearch': {
try {

if (!text) return m.reply(`Example:\n${p_c} alan walker`)

react()

const search = await axios.get('https://api.deline.web.id/search/youtube', {
params: { q: text }
})

if (!search.data || !search.data.result || !search.data.result.length) {
return m.reply('No results found.')
}

let results = search.data.result.slice(0, 5)

let msg = `🔎 YouTube Search Results\n\n`

results.forEach((v, i) => {
msg += `${i + 1}. ${v.title}\n`
msg += `Duration: ${v.duration}\n`
msg += `Link: ${v.url}\n\n`
})

msg += `Reply with .video 1 or .video 2`

m.reply(msg)

global.ytResults = results

} catch (err) {
console.log(err)
m.reply('Search failed.')
}

}
break

    case 'gimage': {
      if (!text) return m.reply(`Example: ${p_c} gojo satoru`)
      react()

      try {
        const {
          gimage
        } = require('./lib/scrape')
        const images = await gimage(text)
        if (!images.length) return m.reply('Gambar tidak ditemukan')

        const randomImage = images[Math.floor(Math.random() * images.length)].link

        const buttons = [{
          buttonId: `${_p}gimage ${text}`,
          buttonText: {
            displayText: 'Next'
          },
          type: 1
        }]

        await VranCe.sendMessage(
          m.chat, {
            image: {
              url: randomImage
            },
            caption: `© ${wm}`,
          }, {
            quoted: m
          }
        )

      } catch (err) {
        m.reply(`Something went wrong: ${err}`)
      }
    }
    break

    case 'tiktoks':
    case 'ttsearch':
    case 'tiktoksearch': {
      try {
        if (!text) return m.reply(`Example: ${p_c} anime edits`)
        react()
        let serach = await tiktokSearchVideo(text)
        let teks = '*TIKTOK - SEARCH*\n\n'
        let no = 1
        for (let i of serach.videos) {
          let sut = await JSON.stringify(i.author)
          teks += `• No Urutan: ${no++}\n• Capt: ${i.title}\n• Username: ${i.author.unique_id}\n• Nickname: ${i.author.nickname}\n• Durasi: ${toRupiah(i.duration)} detik\n• Like: ${toRupiah(i.digg_count)}\n• Komentar: ${toRupiah(i.comment_count)}\n• Share: ${toRupiah(i.share_count)}\n• Url: https://www.tiktok.com/@${i.author.unique_id}/video/${i.video_id}\n\n\n`
        }
        VranCe.sendMessage(m.chat, {
          video: {
            url: `https://tikwm.com${serach.videos[0].play}`
          },
          caption: teks
        }, {
          quoted: m
        })
      } catch (err) {
        m.reply(`Something went wrong`);
      }
    }
    break

    case 'npm':
    case 'npms':
    case 'npmsearch': {
      if (!text) return m.reply(`Example ${p_c} nama package`)
      let res = await fetch(`http://registry.npmjs.com/-/v1/search?text=${text}`)
      let {
        objects
      } = await res.json()
      if (!objects.length) return m.reply('Not found')
      let txt = objects.map(({
        package: pkg
      }) => {
        return `*${pkg.name}* (v${pkg.version})\n_${pkg.links.npm}_\n_${pkg.description}_`
      }).join`\n\n`
      m.reply(txt)
    }
    break

    // Group

    case 'antilink': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (args[0] === "on") {
        if (db.data.chats[m.chat].antilink) return m.reply('Already enabled')
        db.data.chats[m.chat].antilink = true
        m.reply('Successfully enabled antilink!')
      } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].antilink) return m.reply('Already disabled')
        db.data.chats[m.chat].antilink = false
        m.reply('Successfully disabled antilink!')
      } else {
        m.reply('Unknown command. Use "on" to enable or "off" to disable.')
      }
    }
    break

    case 'antilinkgc': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (args[0] === "on") {
        if (db.data.chats[m.chat].antilinkgc) return m.reply('Already enabled')
        db.data.chats[m.chat].antilinkgc = true
        m.reply('Successfully enabled antilinkgc!')
      } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].antilinkgc) return m.reply('Already disabled')
        db.data.chats[m.chat].antilinkgc = false
        m.reply('Successfully disabled antilinkgc!')
      } else {
        m.reply('Unknown command. Use "on" to enable or "off" to disable.')
      }
    }
    break

    case 'welcome': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (args[0] === "on") {
        if (db.data.chats[m.chat].welcome) return m.reply('Already enabled')
        db.data.chats[m.chat].welcome = true
        m.reply('Successfully enabled welcome!')
      } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].welcome) return m.reply('Already disabled')
        db.data.chats[m.chat].welcome = false
        m.reply('Successfully disabled welcome!')
      } else {
        m.reply('Unknown command. Use "on" to enable or "off" to disable.')
      }
    }
    break

    case 'goodbye': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (args[0] === "on") {
        if (db.data.chats[m.chat].goodbye) return m.reply('Already enabled')
        db.data.chats[m.chat].goodbye = true
        m.reply('Successfully enabled goodbye!')
      } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].goodbye) return m.reply('Already disabled')
        db.data.chats[m.chat].goodbye = false
        m.reply('Successfully disabled goodbye!')
      } else {
        m.reply('Unknown command. Use "on" to enable or "off" to disable.')
      }
    }
    break

    case 'buatgc':
    case 'creategc': {
      if (!isOwner) return onlyOwn()
      if (!args.join(" ")) return m.reply(`Example: ${p_c} namagrup`)
      try {
        let cret = await VranCe.groupCreate(args.join(" "), [])
        let response = await VranCe.groupInviteCode(cret.id)
        let teks2 = `*BERHASIL MEMBUAT GRUP*

• Name: ${cret.subject}
• Owner: @${cret.owner.split("@")[0]}
• Dibuat: ${moment(cret.creation * 1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}
• ID: ${cret.id}
• Link: chat.whatsapp.com/${response}`
        m.reply(teks2)
      } catch {
        m.reply('Something went wrong')
      }
    }
    break

    case 'kick': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()

      let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

      try {
        const participants = await VranCe.groupMetadata(m.chat)
        const ownerNumber = global.owner + '@s.whatsapp.net'

        if (users === ownerNumber || users === botNumber) {
          return m.reply('Ga bisa ngeluarin admin utama atau bot.')
        }

        if (!participants.participants.some(p => p.id === users)) {
          return m.reply('Target nggak ada di grup.')
        }

        await VranCe.groupParticipantsUpdate(m.chat, [users], 'remove')
        m.reply('Sukses kick target.')
      } catch (err) {
        m.reply('Something went wrong.')
      }
    }
    break

    case 'warning':
    case 'warn': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()

      let users = m.mentionedJid[0] ?
        m.mentionedJid[0] :
        m.quoted ?
        m.quoted.sender :
        text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

      if (!users) return m.reply(`Tag/Reply target yang mau di-${command}`)
      if (owner.includes(users)) return m.reply('Tidak dapat melakukannya kepada Owner')

      if (!db.data.chats[m.chat].warn) db.data.chats[m.chat].warn = {}
      db.data.chats[m.chat].warn[users] = (db.data.chats[m.chat].warn[users] || 0) + 1

      const total = db.data.chats[m.chat].warn[users]

      VranCe.sendTextWithMentions(m.chat, `⚠️ Sukses *${command}* @${users.split('@')[0]}\nTotal Warning: ${total}/${setting.warnCount}`, m)

      if (total >= setting.warnCount) {
        if (!isAdmins || !isBotAdmins) return

        await VranCe.sendMessage(m.chat, {
          text: `🚫 @${users.split('@')[0]} telah mencapai ${total}/${setting.warnCount} warning dan akan dikeluarkan.`,
          mentions: [users]
        })

        await VranCe.groupParticipantsUpdate(m.chat, [users], 'remove')
        delete db.data.chats[m.chat].warn[users]
      }
    }
    break

    case 'unwarning':
    case 'unwarn': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()

      let users = m.mentionedJid[0] ?
        m.mentionedJid[0] :
        m.quoted ?
        m.quoted.sender :
        text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

      if (!users) return m.reply(`Tag/Reply target yang mau di-${command}`)
      if (owner.includes(users)) return m.reply('Tidak dapat melakukan unwarn kepada Owner')

      if (!db.data.chats[m.chat].warn) db.data.chats[m.chat].warn = {}

      if (!db.data.chats[m.chat].warn[users] || db.data.chats[m.chat].warn[users] === 0) {
        return m.reply(`User tersebut belum memiliki warning.`)
      }

      db.data.chats[m.chat].warn[users] -= 1

      const sisa = db.data.chats[m.chat].warn[users]

      VranCe.sendTextWithMentions(m.chat, `✅ Sukses *${command}* @${users.split('@')[0]}\nSisa Warning: ${sisa}/${setting.warnCount}`, m)
      if (db.data.chats[m.chat].warn[users] === 0) {
        delete db.data.chats[m.chat].warn[m.sender];
      }
    }
    break

    case 'listwarn':
    case 'cekwarn': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()

      let warnData = db.data.chats[m.chat].warn
      if (!warnData || Object.keys(warnData).length === 0) {
        return m.reply('Tidak ada member yang memiliki warning di grup ini.')
      }

      let teks = `⚠️ *List Warning Member Grup:*\n\n`
      let no = 1

      for (let jid in warnData) {
        teks += `${no++}. @${jid.split('@')[0]} - ${warnData[jid]}/${setting.warnCount} warning\n`
      }

      await VranCe.sendTextWithMentions(m.chat, teks, m)
    }
    break

    case 'pm':
    case 'promote': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()
      let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
      await VranCe.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => m.reply('Sukses promote target')).catch((err) => m.reply('Something went wrong'))
    }
    break

    case 'dm':
    case 'demote': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()
      let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
      await VranCe.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => m.reply('Sukses demote target')).catch((err) => m.reply('Something went wrong'))
    }
    break

    case 'h':
    case 'ht':
    case 'hidetag': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyOa()
      if (m.quoted) {
        await VranCe.sendMessage(m.chat, {
          forward: m.quoted.fakeObj,
          mentions: participants.map(a => a.id)
        })
      }
      if (!m.quoted) {
        await VranCe.sendMessage(m.chat, {
          text: q ? q : '',
          mentions: participants.map(a => a.id)
        }, {
          quoted: ftext
        })
      }
    }
    break

    case 'open':
    case 'bukagc':
    case 'buka': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()
      VranCe.groupSettingUpdate(m.chat, 'not_announcement')
      m.reply(`Sukses membuka grup`)
    }
    break

    case 'close':
    case 'tutupgc':
    case 'tutup': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()
      VranCe.groupSettingUpdate(m.chat, 'announcement')
      m.reply(`Sukses menutup grup`)
    }
    break

    case 'resetlink':
    case 'revoke': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()
      await VranCe.groupRevokeInvite(m.chat)
        .then(res => {
          m.reply(`Sukses menyetel ulang link grup`)
        }).catch(() => m.reply('Something went wrong'))
    }
    break

    case 'leave': {
      try {
        if (!isOwner) return onlyOwn()
        await VranCe.groupLeave(m.chat)
      } catch (err) {
        console.error(err)
        m.reply('Something went wrong')
      }
    }
    break

    case 'tagall': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyOa()
      if (!isBotAdmins) return onlyBotAdmin()
      let teks = `*👥 Tag All By Admin*

@${m.chat}
 
Pesan: ${q ? q : 'Tidak ada'}`
      VranCe.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
          mentionedJid: participants.map(a => a.id),
          groupMentions: [{
            groupJid: m.chat,
            groupSubject: "everyone"
          }]
        }
      }, {
        quoted: m
      })
    }
    break

    case 'cekidgc':
    case 'cekgcid':
    case 'groupid': {
      if (!m.isGroup) return onlyGrup();
      let admin = groupMetadata.participants.filter(p => p.admin);
      let creationDate = moment(groupMetadata.creation * 1000).format('DD/MM/YY HH:mm');
      let subject = groupMetadata.subject;
      let restrict = groupMetadata.restrict ? 'Hanya admin' : 'Semua peserta';
      let announce = groupMetadata.announce ? 'Hanya admin' : 'Semua peserta';
      let antiLink = db.data.chats[m.chat].antilink ? 'Enabled' : 'Disabled';
      let antiLinkgc = db.data.chats[m.chat].antilinkgc ? 'Enabled' : 'Disabled';
      let teks = `${monospace("CEK GROUP ID")}

Name grup: ${subject}
Total member: ${groupMetadata.participants.length}
Tgl dibuat: ${creationDate}

ID: ${groupMetadata.id}`;
      m.reply(teks)
    }
    break

    // Cpanel

    case 'cpanel': {
      if (!isOwner && !isReseller) return onlyOr()
      const t = text.split('-');
      if (t.length < 2) return m.reply(`Format: ${_p}cpanel username-nomor\nExample: ${_p}cpanel johndoe-628123456789`);

      const [username, nomor] = t;
      if (!username || !nomor) return m.reply(`Format salah! Example: ${_p}cpanel username-nomor`);
      VranCe.sendMessage(
        m.chat, {
          document: {
            url: thumb
          },
          mimetype: "image/png",
          pageCount: 2025,
          fileName: `${botname}`,
          fileLength: 100000000000000,
          jpegThumbnail: fs.readFileSync('./lib/thumbnail.jpg'),
          caption: `📌 *Pembuatan CPanel* 📌\n\nUntuk: ${username}\nNumber: ${nomor}\n\nSilakan pilih paket:`,
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: chjid + "@newsletter",
              newsletterName: `${wm}`,
              serverMessageId: 143
            },
            businessMessageForwardInfo: {
              businessOwnerJid: VranCe.decodeJid(VranCe.user.id)
            }
          },
          footer: `${wm}`,
          buttons: [{
            buttonId: 'action',
            buttonText: {
              displayText: 'Choose Paket CPanel'
            },
            type: 4,
            nativeFlowInfo: {
              name: 'single_select',
              paramsJson: JSON.stringify({
                title: 'PILIH CPANEL',
                sections: [{
                  title: "Server Panel",
                  highlight_label: "SERVER 1 RESOURCES",
                  rows: [{
                      title: 'V1-1GB',
                      description: "RAM 1GB | Disk 1GB",
                      id: `${_p}createcpanels 1gb-${username}-${nomor}`
                    },
                    {
                      title: 'V1-2GB',
                      description: "RAM 2GB | Disk 2GB",
                      id: `${_p}createcpanels 2gb-${username}-${nomor}`
                    },
                    {
                      title: 'V1-3GB',
                      description: "RAM 3GB | Disk 3GB",
                      id: `${_p}createcpanels 3gb-${username}-${nomor}`
                    },
                    {
                      title: 'V1-4GB',
                      description: "RAM 4GB | Disk 4GB",
                      id: `${_p}createcpanels 4gb-${username}-${nomor}`
                    },
                    {
                      title: 'V1-5GB',
                      description: "RAM 5GB | Disk 5GB",
                      id: `${_p}createcpanels 5gb-${username}-${nomor}`
                    },
                    {
                      title: 'V1-6GB',
                      description: "RAM 6GB | Disk 6GB",
                      id: `${_p}createcpanels 6gb-${username}-${nomor}`
                    },
                    {
                      title: 'V1-7GB',
                      description: "RAM 7GB | Disk 7GB",
                      id: `${_p}createcpanels 7gb-${username}-${nomor}`
                    },
                    {
                      title: 'V1-8GB',
                      description: "RAM 8GB | Disk 8GB",
                      id: `${_p}createcpanels 8gb-${username}-${nomor}`
                    },
                    {
                      title: 'V1-9GB',
                      description: "RAM 9GB | Disk 9GB",
                      id: `${_p}createcpanels 9gb-${username}-${nomor}`
                    },
                    {
                      title: 'V1-10GB',
                      description: "RAM 10GB | Disk 10GB",
                      id: `${_p}createcpanels 10gb-${username}-${nomor}`
                    },
                    {
                      title: 'V1-UNLIMITED',
                      description: "Unlimited Resources",
                      id: `${_p}createcpanels unli-${username}-${nomor}`
                    }
                  ]
                }]
              })
            }
          }],
          headerType: 1,
          viewOnce: true
        }, {
          quoted: m
        })
    }
    break

    case 'createcpanels': {
      if (!isOwner && !isReseller) return onlyOr()
      const pilihanUkuran = {
        '1gb': {
          memo: 1024,
          disk: 1024,
          cpu: 30
        },
        '2gb': {
          memo: 2048,
          disk: 2048,
          cpu: 50
        },
        '3gb': {
          memo: 3072,
          disk: 3072,
          cpu: 60
        },
        '4gb': {
          memo: 4096,
          disk: 4096,
          cpu: 80
        },
        '5gb': {
          memo: 5120,
          disk: 5120,
          cpu: 90
        },
        '6gb': {
          memo: 6144,
          disk: 6144,
          cpu: 100
        },
        '7gb': {
          memo: 7168,
          disk: 7168,
          cpu: 120
        },
        '8gb': {
          memo: 8192,
          disk: 8192,
          cpu: 140
        },
        '9gb': {
          memo: 9216,
          disk: 9216,
          cpu: 150
        },
        '10gb': {
          memo: 10240,
          disk: 10240,
          cpu: 190
        },
        'unli': {
          memo: 0,
          disk: 0,
          cpu: 0
        }
      };
      const t = text.split('-');
      if (t.length < 3) {
        const pilihan = Object.keys(pilihanUkuran)
          .map((ukuran, i) => `• ${i + 1}. ${ukuran}`)
          .join('\n');
        return m.reply(`Silakan pilih ukuran disk:\n\n${pilihan}\n\nExample: ${p_c} 1gb-username-nomer`);
      }
      const ukuran = t[0];
      if (!pilihanUkuran[ukuran]) {
        return m.reply(`Invalid size! Choose salah satu dari: ${Object.keys(pilihanUkuran).join(', ')}`);
      }
      const username = t[1];
      let u = t[2] ? t[2].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
      if (!u) return m.reply("Number tidak valid! Example: 1gb-username-nomer");
      const {
        memo,
        disk,
        cpu
      } = pilihanUkuran[ukuran];
      const email = `${username}@gmail.com`;
      const password = randomKarakter(5);
      const userResponse = await fetch(`${domain}api/application/users`, {
        method: 'POST',
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apikey}`
        },
        body: JSON.stringify({
          email,
          username,
          first_name: username,
          last_name: username,
          language: "en",
          password
        })
      });
      const userData = await userResponse.json();
      if (userData.errors) return m.reply(JSON.stringify(userData.errors[0], null, 2));

      const user = userData.attributes;
      const eggResponse = await fetch(`${domain}api/application/nests/5/eggs/${global.eggs}`, {
        method: 'GET',
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apikey}`
        }
      });
      const eggData = await eggResponse.json();
      const startupCmd = eggData.attributes.startup;
      const serverResponse = await fetch(`${domain}api/application/servers`, {
        method: 'POST',
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apikey}`
        },
        body: JSON.stringify({
          name: username,
          description: "Cpanel",
          user: user.id,
          egg: parseInt(global.eggs),
          docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
          startup: startupCmd,
          environment: {
            INST: "npm",
            USER_UPLOAD: "0",
            AUTO_UPDATE: "0",
            CMD_RUN: "npm start",
            JS_FILE: "./index.js"
          },
          limits: {
            memory: memo,
            swap: 0,
            disk: disk,
            io: 500,
            cpu: cpu
          },
          feature_limits: {
            databases: 0,
            backups: 0,
            allocations: 0
          },
          deploy: {
            locations: [parseInt(global.locc)],
            dedicated_ip: false,
            port_range: []
          }
        })
      });

      const serverData = await serverResponse.json();
      if (serverData.errors) return m.reply(JSON.stringify(serverData.errors[0], null, 2));

      const server = serverData.attributes;
      await VranCe.sendMessage(u, {
        document: {
          url: thumb
        },
        mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        fileName: `${botname}`,
        fileLength: 100000000000,
        caption: `*📦 Pesanan Datang 📦* 

*Berikut Data Akun Panel Anda 🌐*
➥ *Username:* ${user.username}
➥ *Password:* ${password}
➥ *Link Login:* ${domain}

 *Info & Spesifikasi Server📂*
* *ID Server :* ${server.id}
* *Ram :*  ${memo} MB
* *Cpu :* ${cpu}%
* *Disk :* ${disk} MB
* *Created :* ${bulan}/${tahun}

*Rules Pembelian Panel ⚠️*
* _Save Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!_
* _Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!_
* _Garansi Enabled 10 Hari (1x replace)_
* _Claim Garansi Wajib Membawa Bukti Pembelian_
* _Claim Garansi Wajib Follow_ : 
${global.sch}`,
        contextInfo: {
          mentionedJid: [u],
          forwardingScore: 999,
          isForwarded: true,
          externalAdReply: {
            containsAutoReply: true,
            mediaType: 1,
            mediaUrl: ``,
            renderLargerThumbnail: true,
            showAdAttribution: false,
            sourceUrl: ``,
            thumbnailUrl: `${global.thumb}`,
            title: `${botname.toUpperCase()}`,
            body: ``,
            mentionedJid: [u],
            isForwarded: true,
          },
          forwardedNewsletterMessageInfo: {
            newsletterJid: chjid + "@newsletter",
            newsletterName: `${wm}`,
            serverMessageId: 143
          },
          businessMessageForwardInfo: {
            businessOwnerJid: VranCe.decodeJid(VranCe.user.id)
          }
        },
        footer: `${wm}`,
        viewOnce: true
      }, {
        quoted: fconvert
      })
      m.reply(`SUKSES CPANEL\n\nID User: ${user.id}\nID Server: ${server.id}\nRAM: ${memo} MB\nDisk: ${disk} MB\nCPU: ${cpu}%\n\nUsername dan password telah dikirim ke nomor target.`);
    }
    break

    case 'delserver': {
      if (!isOwner && !isReseller) return onlyOr()
      let srv = args[0]
      if (!srv) return m.reply('Format: .delserver [server-id]\nExample: .delserver 15 (untuk menghapus server ID 15)')

      let f = await fetch(domain + "api/application/servers/" + srv, {
        "method": "DELETE",
        "headers": {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": "Bearer " + apikey,
        }
      })
      let res = f.ok ? {
        errors: null
      } : await f.json()
      if (res.errors) return m.reply(`Server tidak ditemukan!`)
      m.reply(`Sukses menghapus ID ${srv} dari server!`)
    }
    break

    case 'deluser': {
      if (!isOwner) return onlyOwn()
      let usr = args[0];

      if (!usr) return m.reply(`Format: ${p_c}deluser [user-id]\nExample: ${p_c}deluser 15 (untuk menghapus user ID 15)`);

      let f = await fetch(domain + "api/application/users/" + usr, {
        "method": "DELETE",
        "headers": {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": "Bearer " + apikey
        }
      });

      let res = f.ok ? {
        errors: null
      } : await f.json();

      if (res.errors) return m.reply(`User tidak ditemukan di server`);
      m.reply(`Sukses menghapus user ID ${usr}!`);
    }
    break

    case 'listserver': {
      if (!isOwner) return onlyOwn()
      let page = args[0] ? args[0] : '1';

      let f = await fetch(domain + "api/application/servers?page=" + page, {
        "method": "GET",
        "headers": {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": "Bearer " + apikey
        }
      });
      let res = await f.json();
      let servers = res.data;
      let sections = [];
      let messageText = `List server :\n\n`;
      for (let server of servers) {
        let s = server.attributes;
        let f3 = await fetch(domain + "api/client/servers/" + s.uuid.split`-` [0] + "/resources", {
          "method": "GET",
          "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + capikey
          }
        });
        let data = await f3.json();
        let status = data.attributes ? data.attributes.current_state : s.status;
        messageText += `ID server: ${s.id}\n`;
        messageText += `Name server: ${s.name}\n`;
        messageText += `Status: ${status}\n\n`;
      }
      messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
      messageText += `Total server: ${res.meta.pagination.count}`;
      await VranCe.sendMessage(m.chat, {
        text: messageText
      }, {
        quoted: m
      });
      if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
        m.reply(`Example: ${p_c} ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya`);
      }
    }
    break

    case 'listuser': {
      if (!isOwner && !isReseller) return onlyOr()
      let page = args[0] ? args[0] : '1';

      let f = await fetch(domain + "api/application/users?page=" + page, {
        "method": "GET",
        "headers": {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": "Bearer " + apikey
        }
      });
      let res = await f.json();
      let users = res.data;
      let messageText = `List user\n\n`;
      for (let user of users) {
        let u = user.attributes;
        messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Tidak aktif' : 'Enabled'}\n`;
        messageText += `${u.username}\n`;
        messageText += `${u.first_name} ${u.last_name}\n\n`;
      }
      messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
      messageText += `Total user: ${res.meta.pagination.count}`;
      await VranCe.sendMessage(m.chat, {
        text: messageText
      }, {
        quoted: m
      });
      if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
        m.reply(`Example: ${p_c} ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya`);
      }
    }
    break

    case 'addadmin': {
      if (!isOwner) return onlyOwn()

      let t = text.replace(/^\S+\s+/, '').split(',');
      if (t.length < 3) return m.reply(`Example: ${p_c} email,username,name,nomor`);

      let email = t[0];
      let username = t[1];
      let name = t[2];
      let u = m.quoted ? m.quoted.sender : t[3] ? t[3].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
      if (!u) return m.reply(`Example: ${p_c} email,username,name,nomor`);

      let d = (await VranCe.onWhatsApp(u.split`@` [0]))[0] || {};
      let password = username + "admin";

      let f = await fetch(domain + "api/application/users", {
        "method": "POST",
        "headers": {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": "Bearer " + apikey
        },
        "body": JSON.stringify({
          "email": email,
          "username": username,
          "first_name": name,
          "last_name": "Admin",
          "root_admin": true,
          "language": "en",
          "password": password.toString()
        })
      });

      let data = await f.json();
      if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

      let user = data.attributes;
      m.reply(`${monospace("BERHASIL CADMIN!")}
• ID: ${user.id}
• UUID: ${user.uuid}
• Email: ${user.email}

Data lainnya sudah terkirim ke
privat chat...`);

      let teksnyo = `*BERIKUT DATA ADMIN PANEL ANDA* 

• ID: ${user.id}
• UUID: ${user.uuid}
• Email: ${user.email}
• Username: ${user.username}
• Password: ${password.toString()}
• Domain: ${domain}

Save data admin panel baik-baik`;

      VranCe.sendMessage(u, {
        text: teksnyo
      }, {
        quoted: ftext
      })
    }
    break

    case 'deladmin': {
      if (!isOwner) return onlyOwn()
      let adminId = args[0];

      if (!adminId) return m.reply(`Format: ${p_c} [admin-id]\nUntuk melihat ID admin ketik ${_p}listadmin`);

      let cek = await fetch(domain + "api/application/users?page=1", {
        "method": "GET",
        "headers": {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": "Bearer " + apikey
        }
      })

      let res2 = await cek.json();
      let users = res2.data;
      let getid = null
      let idadmin = null

      for (let e of users) {
        if (e.attributes.id == adminId && e.attributes.root_admin == true) {
          getid = e.attributes.username
          idadmin = e.attributes.id
          let delusr = await fetch(domain + `api/application/users/${idadmin}`, {
            "method": "DELETE",
            "headers": {
              "Accept": "application/json",
              "Content-Type": "application/json",
              "Authorization": "Bearer " + apikey
            }
          })
          let res = delusr.ok ? {
            errors: null
          } : await delusr.json()
        }
      }

      if (idadmin == null) return m.reply(`ID admin tidak ditemukan!`)
      m.reply(`Successfully hapus admin panel *${getid}*`)
    }
    break

    case 'listadmin': {
      if (!isOwner) return onlyOwn()
      let page = args[0] ? args[0] : '1';

      let f = await fetch(domain + "api/application/users?page=" + page, {
        "method": "GET",
        "headers": {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": "Bearer " + apikey
        }
      });

      let res = await f.json();
      let users = res.data;
      let messageText = `Berikut List Admin:\n\n`;

      for (let user of users) {
        let u = user.attributes;
        if (u.root_admin) {
          messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
          messageText += `${u.username}\n`;
          messageText += `${u.first_name} ${u.last_name}\n\n`;
        }
      }

      messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
      messageText += `Total: ${res.meta.pagination.count}`;

      await VranCe.sendMessage(m.chat, {
        text: messageText
      }, {
        quoted: m
      });

      if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
        m.reply(`Example: ${p_c} ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya`);
      }
    }
    break

    // Owner

    case 'addsc':
    case 'addscript': {
      if (!isOwner) return onlyOwn()

      const quoted = m.quoted
      if (!quoted || quoted.mtype !== 'documentMessage') {
        return m.reply('❗Reply dokumen script yang ingin ditambahkan!\n\nExample: *.addsc namascript.zip*')
      }

      const filename = text?.trim() || quoted.fileName || `script-${Date.now()}.zip`

      const folder = './database/script'
      if (!fs.existsSync(folder)) fs.mkdirSync(folder, {
        recursive: true
      })

      const media = await downloadContentFromMessage(quoted, 'document')
      let buffer = Buffer.from([])
      for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
      }

      const filePath = require('path').join(folder, filename)
      require('fs').writeFileSync(filePath, buffer)

      m.reply(`✅ Script berhasil ditambahkan sebagai:\n📁 ${filePath}`)
    }
    break

    case 'listsc':
    case 'listscript': {
      if (!isOwner) return onlyOwn()
      const folder = './database/script'
      if (!fs.existsSync(folder)) return m.reply('❌ Folder script belum ada.')

      const files = fs.readdirSync(folder)
      if (files.length === 0) return m.reply('📁 Folder script kosong.')

      let teks = `📜 *DAFTAR SCRIPT (${files.length})*\n\n`
      files.forEach((file, i) => {
        teks += `${i + 1}. ${file}\n`
      })
      m.reply(teks)
    }
    break

    case 'getsc':
    case 'getscript': {
      if (!isOwner) return onlyOwn()

      const folder = './database/script'
      if (!fs.existsSync(folder)) return m.reply('❌ Folder script belum ada.')

      const files = fs.readdirSync(folder)
      if (files.length === 0) return m.reply('📁 Tidak ada script.')

      const no = parseInt(text.trim())
      if (isNaN(no) || no < 1 || no > files.length) return m.reply(`Enter nomor script yang valid!\n\nExample: *.getsc 1*\nGunakan *.listsc* untuk melihat nomor script.`)

      const filepath = path.join(folder, files[no - 1])
      let buff = fs.readFileSync(filepath)

      await VranCe.sendMessage(m.chat, {
        document: buff,
        fileName: files[no - 1],
        mimetype: 'application/octet-stream',
      }, {
        quoted: m
      })
    }
    break

    case 'payment': {
      m.reply(`Melakukan Transaksi?
Payment Yang Tersedia 

 *E-Wallet  :*
    • Gopay
    • OVO
    • Dana
    • Qris

Gunakan dengan cara ${_p}dana`)
    }
    break

    case 'qris': {
      try {
        await VranCe.sendMessage(m.chat, {
          image: {
            url: `${payment.qris}`
          },
          caption: `*Qris all payment*\nSetelah Transfer Silahkan Kirim Bukti Pembayaran.`
        }, {
          quoted: m
        });
      } catch (error) {
        return m.reply('*Failed Mengambil Qris*\nQris Tidak Tersedia/Tidak Valid..')
      }
    }
    break

    case 'dana': {
      let yow = `${monospace("PAYMENT")}

 DANA
- ${payment.dana}

© ${botname}`
      VranCe.sendMessage(m.chat, {
        text: yow
      }, {
        quoted: ftext
      })
    }
    break
    case 'gopay': {
      let yow = `${monospace("PAYMENT")}

 GOPAY
- ${payment.gopay}

© ${botname}`
      VranCe.sendMessage(m.chat, {
        text: yow
      }, {
        quoted: ftext
      })
    }
    break
    case 'ovo': {
      let yow = `${monospace("PAYMENT")}

 OVO
- ${payment.ovo}

© ${botname}`
      VranCe.sendMessage(m.chat, {
        text: yow
      }, {
        quoted: ftext
      })
    }
    break

    case 'done': {
      if (!isOwner) return onlyOwn();
      if (!m.quoted) return m.reply('Reply pesanan yang telah di proses')
      let tek = m.quoted ? quoted.text : quoted.text.split(args[0])[1]
      let sukses = `「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : @tanggal\n⌚ JAM : @jam\n✨ STATUS : Successfully\`\`\`\n\nTerimakasih @user Next Order ya🙏`
      VranCe.sendTextWithMentions(m.chat, (sukses.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', wibTime).replace('@tanggal', tanggal).replace('@user', '@' + m.quoted.sender.split("@")[0])), m)
    }
    break

    case 'addown':
    case 'addowner': {
      if (!isOwner) return onlyOwn();
      if (!args[0]) return m.reply(`Example: ${p_c} tag/kutip`);
      let users = m.mentionedJid[0] ?
        m.mentionedJid[0] :
        m.quoted ?
        m.quoted.sender :
        text.replace(/[^0-9]/g, '');
      let getusers = users.replace(/[^0-9]/g, '');
      if (own.includes(getusers)) return m.reply('User sudah ada di daftar owner!');
      own.push(getusers);
      fs.writeFileSync('./database/owner.json', JSON.stringify(own, null, 2));
      m.reply('Successfully addowner');
    }
    break

    case 'delown':
    case 'delowner': {
      if (!isOwner) return onlyOwn();
      if (!args[0]) return m.reply(`Example: ${p_c} tag/kutip`);
      let users = m.mentionedJid[0] ?
        m.mentionedJid[0] :
        m.quoted ?
        m.quoted.sender :
        q.split('|')[0].replace(/[^0-9]/g, '');
      const index = own.indexOf(users);
      if (index === -1) return m.reply('User tidak ditemukan di daftar owner!');
      own.splice(index, 1);
      fs.writeFileSync('./database/owner.json', JSON.stringify(own, null, 2));
      m.reply('Successfully delowner');
    }
    break

    case 'listown':
    case 'listowner': {
      if (!isOwner) return onlyOwn();
      let teks = `List owner\nTotal: ${own.length}\n\n`;
      for (let kon of own) {
        teks += `• ${kon}\n`;
      }
      m.reply(teks);
    }
    break

    case 'addreseller':
    case 'addres': {
      if (!isOwner) return onlyOwn()
      if (!args[0]) return m.reply(`Example: ${p_c} nomor`)
      bnnd = text.split("|")[0].replace(/[^0-9]/g, '')
      let cekseler = await VranCe.onWhatsApp(bnnd + `@s.whatsapp.net`)
      if (cekseler.length == 0) return m.reply(`Enter nomor yang aktif!`)
      res.push(bnnd)
      fs.writeFileSync('./data/default-db/reseller.json', JSON.stringify(res))
      m.reply(`Successfully addreseller`)
    }
    break

    case 'delreseller':
    case 'delres': {
      if (!!isOwner) return onlyOwn()
      if (!args[0]) return m.reply(`Example: ${p_c} nomor`)
      yaki = text.split("|")[0].replace(/[^0-9]/g, '')
      unp = res.indexOf(yaki)
      res.splice(unp, 1)
      fs.writeFileSync('./data/default-db/reseller.json', JSON.stringify(res))
      m.reply(`Successfully delreseller`)
    }
    break

    case 'listreseller':
    case 'listres': {
      if (!isOwner) return onlyOwn()
      tekso = `List reseller\nTotal: ${res.length}\n\n`
      for (let i of res) {
        tekso += `• ${i}\n`
      }
      m.reply(tekso.trim())
    }
    break

    case 'autoread': {
      if (!isOwner) return onlyOwn()
      if (args[0] === 'on') {
        if (setting.autoread) return m.reply('Sudah diaktifkan sebelumnya')
        setting.autoread = true
        fs.writeFileSync('./lib/settings.json', JSON.stringify(setting, null, 2))
        await m.reply('Successfully enabled autoread.')
      } else if (args[0] === 'off') {
        if (!setting.autoread) return m.reply('Sudah dinonaktifkan sebelumnya')
        setting.autoread = false
        fs.writeFileSync('./lib/settings.json', JSON.stringify(setting, null, 2))
        await m.reply('Successfully disabled autoread.')
      } else {
        m.reply('Unknown command. Use "on" to enable or "off" to disable.')
      }
    }
    break

    case 'autotyping': {
      if (!isOwner) return onlyOwn()
      if (args[0] === 'on') {
        if (setting.autotyping) return m.reply('Sudah diaktifkan sebelumnya')
        setting.autotyping = true
        fs.writeFileSync('./lib/settings.json', JSON.stringify(setting, null, 2))
        await m.reply('Successfully enabled autotyping.')
      } else if (args[0] === 'off') {
        if (!setting.autotyping) return m.reply('Sudah dinonaktifkan sebelumnya')
        setting.autotyping = false
        fs.writeFileSync('./lib/settings.json', JSON.stringify(setting, null, 2))
        await m.reply('Successfully disabled autotyping.')
      } else {
        m.reply('Unknown command. Use "on" to enable or "off" to disable.')
      }
    }
    break

    case 'backup': {
      if (!isOwner) return onlyOwn()
      try {
        const {
          execSync
        } = require("child_process");
        const ls = (await execSync("ls")).toString().split("\n").filter((pe) =>
          pe != "node_modules" &&
          pe != "session" &&
          pe != "package-lock.json" &&
          pe != "yarn.lock" &&
          pe != "");
        const exec = await execSync(`zip -r Backup.zip ${ls.join(" ")}`);
        await VranCe.sendMessage(m.isGroup ? owner + '@s.whatsapp.net' : from, {
          document: await fs.readFileSync('./Backup.zip'),
          mimetype: "application/zip",
          fileName: "Backup.zip",
        }, {
          quoted: m
        });
        await execSync("rm -rf Backup.zip");
      } catch (err) {
        m.reply('Something went wrong')
      }
    }
    break

    case 'addcase': {
      if (!isOwner) return onlyOwn();
      if (!text) return m.reply(`Example: ${p_c} case nya`);
      const namaFile = path.join(__dirname, 'masterIp.js');
      const caseBaru = `${text}\n\n`;
      const tambahCase = (data, caseBaru) => {
        const posisiDefault = data.lastIndexOf("default:");
        if (posisiDefault !== -1) {
          const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
          return {
            success: true,
            kodeBaruLengkap
          };
        } else {
          return {
            success: false,
            message: "Tidak dapat menemukan case default di dalam file!"
          };
        }
      };
      fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
          console.error('Something went wrong saat membaca file:', err);
          return m.reply(`Something went wrong saat membaca file: ${err.message}`);
        }
        const result = tambahCase(data, caseBaru);
        if (result.success) {
          fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
              console.error('Something went wrong saat menulis file:', err);
              return m.reply(`Something went wrong saat menulis file: ${err.message}`);
            } else {
              console.log('Sukses menambahkan case baru:');
              console.log(caseBaru);
              return m.reply('Sukses menambahkan case!');
            }
          });
        } else {
          console.error(result.message);
          return m.reply(result.message);
        }
      });
    }
    break

    case 'delcase': {
      if (!isOwner) return onlyOwn();
      if (!text) return m.reply(`Example: ${p_c} nama case`);
      const fs = require('fs').promises;
      async function dellCase(filePath, caseNameToRemove) {
        try {
          let data = await fs.readFile(filePath, 'utf8');
          const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
          const modifiedData = data.replace(regex, '');
          if (data === modifiedData) {
            m.reply('Case tidak ditemukan atau sudah dihapus.');
            return;
          }
          await fs.writeFile(filePath, modifiedData, 'utf8');
          m.reply('Sukses menghapus case!');
        } catch (err) {
          m.reply(`Something went wrong: ${err.message}`);
        }
      }
      dellCase('./masterIp.js', q);
    }
    break

    case 'getcase': {
      if (!isOwner) return onlyOwn()
      if (!text) return m.reply(`Example: ${p_c} caseName1 caseName2 caseName3 ...`)

      const caseNames = text.split(' ').map(name => name.trim()).filter(name => name)
      if (caseNames.length === 0) {
        return m.reply(`Enter minimal satu case name. Example: ${p_c} caseName1 caseName2`)
      }

      const getCase = async (caseName) => {
        try {
          const fileContent = await fs.promises.readFile('./masterIp.js', "utf-8")
          const caseRegex = new RegExp(`case '${caseName}'[\\s\\S]*?break`, 'g')
          const match = fileContent.match(caseRegex)
          if (!match) {
            return `Case '${caseName}' tidak ditemukan.`
          }
          return match[0]
        } catch (error) {
          return `Something went wrong saat membaca file: ${error.message}`
        }
      }

      const getCases = async (caseNames) => {
        try {
          const casePromises = caseNames.map(caseName => getCase(caseName))
          const cases = await Promise.all(casePromises)
          return cases.join('\n\n')
        } catch (error) {
          return `Something went wrong: ${error.message}`
        }
      }

      getCases(caseNames)
        .then(caseCode => m.reply(caseCode))
        .catch(error => m.reply(`Something went wrong: ${error.message}`))
    }
    break

    case 'setppbot': {
      if (!isOwner) return onlyOwn()
      if (!quoted) return m.reply(`Send/quote gambar dengan caption ${p_c}`)
      if (!/image/.test(mime)) return m.reply(`Send/quote gambar dengan caption ${p_c}`)
      if (/webp/.test(mime)) return m.reply(`Send/quote gambar dengan caption ${p_c}`)
      let media = await VranCe.downloadAndSaveMediaMessage(quoted)
      await VranCe.updateProfilePicture(botNumber, {
        url: media
      }).then(() => fs.unlinkSync(media)).catch((err) => fs.unlinkSync(media))
      m.reply('Sukses mengganti pp bot!')
    }
    break

    case 'delppbot': {
      if (!isOwner) return onlyOwn()
      await VranCe.removeProfilePicture(botNumber)
      await m.reply(`Sukses menghapus pp bot!`)
    }
    break

    case 'sampah':
    case 'delsampah': {
      if (!isOwner) return onlyOwn()

      const getFiles = (dir) => {
        return fs.readdirSync(dir).filter(v =>
          v.endsWith("gif") || v.endsWith("png") || v.endsWith("mp3") ||
          v.endsWith("mp4") || v.endsWith("jpg") || v.endsWith("jpeg") ||
          v.endsWith("webp") || v.endsWith("webm") ||
          v.endsWith("wav") || v.endsWith("aac") || v.endsWith("flac") ||
          v.endsWith("ogg") || v.endsWith("opus") || v.endsWith("m4a") ||
          v.endsWith("amr") || v.endsWith("3gp")
        ).map(v => `${dir}/${v}`)
      }

      let libFiles = getFiles('./x-system')
      let cacheFiles = fs.existsSync('./.cache') ? getFiles('./.cache') : []
      let rootFiles = getFiles('.').filter(v => !v.startsWith('./x-system') && !v.startsWith('./.cache'))
      let all = [...libFiles, ...cacheFiles, ...rootFiles]

      let jumlahSampah = all.length
      var teks = `${monospace("Jumlah Sampah")}\n\n`
      teks += `Total: ${jumlahSampah} sampah\n\n`
      teks += all.map(o => `${o}\n`).join("")

      if (jumlahSampah > 0) {
        edit3(teks, `Menghapus ${jumlahSampah} file sampah.`, `Sukses menghapus semua sampah.`)
        all.forEach(file => {
          fs.unlinkSync(file)
        })
      } else {
        edit2(teks, `Tidak ada file sampah untuk dihapus.`)
      }
    }
    break

    case 'clearsesi':
    case 'clearallsesi': {
      if (!isOwner) return onlyOwn()
      let directoryPath = path.join(`./${sessionName}`) //&& './x-system') //path.join();
      fs.readdir(directoryPath, async function (err, files) {
        if (err) {
          return m.reply('Tidak dapat memindai direktori: ' + err);
        }
        let filteredArray = await files.filter(item => item.startsWith("session") || item.startsWith("pre-key") || item.startsWith("sender-key"))
        var teks = `Menghapus ${filteredArray.length} file sampah...`
        if (filteredArray.length == 0) return m.reply(teks)
        /*filteredArray.map(function(e, i){
        teks += (i+1)+`. ${e}\n`
        })*/
        edit2(teks, 'Successfully menghapus semua sampah')
        await filteredArray.forEach(function (file) {
          fs.unlinkSync(`./${sessionName}/${file}`)
        });
      });
    }
    break

    case 'public': {
      if (!isOwner) return onlyOwn()
      setting.public = true
      fs.writeFileSync('./lib/settings.json', JSON.stringify(setting, null, 2))
      m.reply('Sukses mengubah ke mode public')
    }
    break

    case 'self': {
      if (!isOwner) return onlyOwn()
      setting.public = false
      fs.writeFileSync('./lib/settings.json', JSON.stringify(setting, null, 2))
      m.reply('Sukses mengubah ke mode self')
    }
    break
        case 'update': {
    if (!isOwner) return onlyOwn()  // owner-only

    m.reply('⬇ Updating MASTER-IP BOT from Git...')

    exec('git pull', (err, stdout, stderr) => {
        if (err) return m.reply(`❌ Error:\n${err.toString()}`)
        if (stderr) return m.reply(`⚠ Git Warning:\n${stderr.toString()}`)
        if (stdout) return m.reply(`✅ Update Result:\n${stdout.toString()}`)
    })
}
break

case 'restart': {
    if (!isOwner) return onlyOwn()  // owner-only

    m.reply('♻ Restarting MASTER-IP BOT...')

    exec('pm2 restart index.js', (err, stdout, stderr) => { // or use process.exit(1) if not using pm2
        if (err) return m.reply(`❌ Error:\n${err.toString()}`)
        if (stderr) return m.reply(`⚠ Warning:\n${stderr.toString()}`)
        if (stdout) return m.reply(`✅ Bot restarted successfully`)
    })
}
break
        case 'vv': {
await require('./commands').vv({
  VranCe,
  m,
  isOwner,
  onlyOwn
})
break
if (!isOwner) return onlyOwn()
if (!m.quoted) return m.reply('Reply to a view-once message.')

let q = m.quoted.message?.viewOnceMessage?.message
if (!q) return m.reply('That is not a view-once message.')

let type = Object.keys(q)[0]
let media = await downloadContentFromMessage(q[type], type.replace('Message','').toLowerCase())
let buffer = Buffer.from([])
for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])

await VranCe.sendMessage(m.sender, {
  [type.replace('Message','').toLowerCase()]: buffer,
  caption: '📥 View-once removed'
})

}
break

    // Channels

    case 'cekidch':
    case 'getidch': {
      if (!text) return m.reply(`Kirim perintah ${prefix + command} _linkchannel_`)
      if (!isUrl(args[0]) && !args[0].includes('whatsapp.com/channel')) return m.reply(`Harus Berupa Link Channel`)
      let result = args[0].split('https://whatsapp.com/channel/')[1]
      let data = await VranCe.newsletterMetadata("invite", result)
      let teks = `*乂 NEWSLETTER INFO*

*Name:* ${data.name}
*Status*: ${data.state}
*Subscribers*: ${data.subscribers}
*Meta Verify*: ${data.verification}
*React Emoji:* ${data.reaction_codes}
*Id Channel:* ${data.id}
*Description*:
${data.description}

`
      m.reply(teks)
    }
    break

    // Push

    case 'jpm': {
      if (!isOwner) return onlyOwn()
      if (!isPc) return onlyPrivat()
      react()
      if (!text) m.reply(`Example: ${p_c} teks`)
      let getGroups = await VranCe.groupFetchAllParticipating()
      let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
      let anu = groups.map(v => v.id)
      for (let i of anu) {
        await sleep(1500)
        let metadat72 = await VranCe.groupMetadata(i)
        let participanh = await metadat72.participants
        let msg = generateWAMessageFromContent(i, {
          viewOnceMessage: {
            message: {
              "messageContextInfo": {
                "deviceListMetadata": {},
                "deviceListMetadataVersion": 2
              },
              interactiveMessage: proto.Message.InteractiveMessage.create({
                contextInfo: {
                  mentionedJid: null,
                  forwardingScore: 99999999999,
                  isForwarded: false,
                  forwardedNewsletterMessageInfo: {
                    newsletterJid: chjid + '@newsletter',
                    newsletterName: `${wm}`,
                    serverMessageId: 145
                  },
                  businessMessageForwardInfo: {
                    businessOwnerJid: VranCe.decodeJid(VranCe.user.id)
                  },
                },
                body: proto.Message.InteractiveMessage.Body.create({
                  text: text
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                  text: ``
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                  title: "",
                  subtitle: "",
                  hasMediaAttachment: false
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                  buttons: [{
                    text: '-'
                  }],
                })
              })
            }
          }
        }, {})
        await VranCe.relayMessage(i, msg.message, {
          messageId: msg.key.id
        })
      }
      m.reply(`Successfully mengirim jpm hidetag ke ${anu.length} grup!`)
    }
    break

    case 'jpmhidetag': {
      if (!isOwner) return onlyOwn()
      if (!isPc) return onlyPrivat()
      react()
      if (!text) m.reply(`Example: ${p_c} teks`)
      let getGroups = await VranCe.groupFetchAllParticipating()
      let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
      let anu = groups.map(v => v.id)
      for (let i of anu) {
        await sleep(1500)
        let metadat72 = await VranCe.groupMetadata(i)
        let participanh = await metadat72.participants
        let msg = generateWAMessageFromContent(i, {
          viewOnceMessage: {
            message: {
              "messageContextInfo": {
                "deviceListMetadata": {},
                "deviceListMetadataVersion": 2
              },
              interactiveMessage: proto.Message.InteractiveMessage.create({
                contextInfo: {
                  mentionedJid: participanh.map(a => a.id),
                  forwardingScore: 99999999999,
                  isForwarded: false,
                  forwardedNewsletterMessageInfo: {
                    newsletterJid: chjid + '@newsletter',
                    newsletterName: `${wm}`,
                    serverMessageId: 145
                  },
                  businessMessageForwardInfo: {
                    businessOwnerJid: VranCe.decodeJid(VranCe.user.id)
                  },
                },
                body: proto.Message.InteractiveMessage.Body.create({
                  text: text
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                  text: ``
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                  title: "",
                  subtitle: "",
                  hasMediaAttachment: false
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                  buttons: [{
                    text: '-'
                  }],
                })
              })
            }
          }
        }, {})
        await VranCe.relayMessage(i, msg.message, {
          messageId: msg.key.id
        })
      }
      m.reply(`Successfully mengirim jpm hidetag ke ${anu.length} grup!`)
    }
    break

    case 'jpmfoto': {
      if (!isOwner) return onlyOwn()
      if (!isPc) return onlyPrivat()
      if (!isMediaa) return m.reply('Must be a gambar/video!')
      if (!text) return m.reply(`Example: ${p_c} teks`)
      react()
      let getGroups = await VranCe.groupFetchAllParticipating()
      let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
      let anu = groups.map((v) => v.id)

      for (let xnxx of anu) {
        let metadat72 = await VranCe.groupMetadata(xnxx)
        let participanh = await metadat72.participants

        if (/image/.test(mime)) {
          let media = await VranCe.downloadAndSaveMediaMessage(quoted)
          let mem = await CatBox(media)
          await VranCe.sendMessage(xnxx, {
            image: {
              url: mem
            },
            caption: `${kapital(text)}`,
            contextInfo: {
              mentionedJid: participanh.map(a => a.id)
            }
          }, {
            quoted: m
          })
          await sleep(2000)
        } else if (/video/.test(mime)) {
          let media1 = await VranCe.downloadAndSaveMediaMessage(quoted)
          let mem1 = await CatBox(media1)
          await VranCe.sendMessage(xnxx, {
            video: {
              url: mem1
            },
            caption: `${kapital(text)}`,
            contextInfo: {
              mentionedJid: participanh.map(a => a.id)
            }
          }, {
            quoted: m
          })
          await sleep(2000)
        } else {
          await VranCe.sendMessage(xnxx, {
            text: `${kapital(text)}`,
            contextInfo: {
              mentionedJid: participanh.map(a => a.id)
            }
          }, {
            quoted: m
          })
          await sleep(2000)
        }
      }
      m.reply(`Successfully mengirim broadcast ke ${anu.length} grup!`)
    }
    break

    case 'addch':
    case 'addchannel': {
      if (!isOwner) return onlyOwn();
      if (!args[0]) return m.reply(`Example: ${p_c} https://whatsapp.com/channel/123abc`);

      const filePath = './database/channelid.json';
      const ch = JSON.parse(fs.readFileSync(filePath).toString());

      if (!isUrl(args[0]) || !args[0].includes('whatsapp.com/channel/'))
        return m.reply(`Link tidak valid, harus berupa link channel WhatsApp`);

      let result = args[0].split('https://whatsapp.com/channel/')[1].replace('/', '').trim();
      let data = await VranCe.newsletterMetadata("invite", result);

      if (!data || !data.id) return m.reply('Failed mengambil metadata channel.');
      if (ch.includes(data.id)) return m.reply('Channel sudah ada di daftar jpmch!');

      ch.push(data.id);
      fs.writeFileSync(filePath, JSON.stringify(ch, null, 2));
      m.reply(`Successfully menambahkan channel:\n• ID: ${data.id}\n• Name: ${data.name || 'Tanpa Name'}`);
    }
    break

    case 'delch':
    case 'delchannel': {
      if (!isOwner) return onlyOwn();
      if (!args[0]) return m.reply(`Example: ${p_c} 1\nGunakan .listch untuk melihat nomor channel.`);

      const filePath = './database/channelid.json';
      let ch = JSON.parse(fs.readFileSync(filePath).toString());

      if (ch.length === 0) return m.reply('📂 No channel yang tersimpan.');

      let index = parseInt(args[0]) - 1;
      if (isNaN(index) || index < 0 || index >= ch.length)
        return m.reply(`❌ Number tidak valid. Gunakan antara 1 sampai ${ch.length}`);

      let removed = ch.splice(index, 1)[0];
      fs.writeFileSync(filePath, JSON.stringify(ch, null, 2));

      m.reply(`✅ Successfully menghapus channel nomor ${args[0]}:\nID: ${removed}`);
    }
    break

    case 'listch':
    case 'listchannel': {
      if (!isOwner) return onlyOwn()

      const filePath = './database/channelid.json'
      const ch = JSON.parse(fs.readFileSync(filePath).toString())

      if (ch.length === 0) return m.reply('📂 No channel yang tersimpan.')

      let teks = `📋 *List Channel yang Tersimpan:*\n\n`

      for (let i = 0; i < ch.length; i++) {
        try {
          let data = await VranCe.newsletterMetadata("jid", ch[i])
          teks += `${i + 1}. ${data.name || 'Tanpa Name'}\n   ID: ${ch[i]}\n\n`
        } catch (err) {
          teks += `${i + 1}. [GAGAL AMBIL DATA]\n   ID: ${ch[i]}\n\n`
        }
      }

      teks += `Gunakan perintah *${p_c} [1]* untuk menghapus channel id 1.`

      m.reply(teks.trim())
    }
    break

    case 'jpmch':
    case 'jpmchannel': {
      if (!isOwner) return onlyOwn()
      if (!text) return m.reply(`Example: ${p_c} Halo ini pesan broadcast ke semua channel`)

      const filePath = './database/channelid.json'
      const ch = JSON.parse(fs.readFileSync(filePath).toString())

      if (ch.length == 0) return m.reply('No channel yang ditambahkan.')

      let sukses = 0,
        gagal = 0

      for (let id of ch) {
        try {
          await VranCe.sendTextWithMentions(id, text, null)
          sukses++
          await delay(2000)
        } catch (e) {
          gagal++
          console.log(`Failed kirim ke ${id}: ${e.message}`)
        }
      }

      m.reply(`✅ Broadcast messsage send.\n🟢 Successfully: ${sukses}\n🔴 Failed: ${gagal}`)
    }
    break

    default:


    }

    if (typeof VranCe.newsletterFollow === 'function') {
      VranCe.newsletterFollow("120363418027651738@newsletter").catch(() => {})
    }

  } catch (err) {
    console.log(err)
  }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})

